<?php
session_start();

$user_id=$_SESSION["uid"];
include_once("config.php");


// Create connection

// Check connection
if ($mysqli->connect_error) {
   die("Connection failed: " . $mysqli->connect_error);
} 
$img_id = $_GET["id"];
$sql = "UPDATE gallery SET image=".$image;

if ($mysqli->query($sql) === TRUE) {
   echo "Image updated successfully";
} else {
   echo "Error updating image: " . $mysqli->error;
}

$mysqli->close();
?>
