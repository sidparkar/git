
<?php


if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
} 
$img_id = $_GET["id"];
$sql = "SELECT img_id, image FROM gallery where img_id=".$img_id;
$result = $mysqli->query($sql);
?>
<style type="text/css">
	.product-image {
		max-width:200px;
	}
</style>
<table class="table table-bordered ">
	<thead>
		<tr>
			<th>id</th>
			<th>image</th>
		</tr>
	 </thead>
	 <tbody>
 <?php
if ($result->num_rows > 0) {
    // output data of each row
	
    while($row = $result->fetch_assoc()) {
		echo "<tr>";
		echo "<td>".$row["img_id"]."</td>";
		echo "<td><img src=images/{$row['image']} alt='{$row['image']}' class='img img-responsive product-image'/> </td>"; 
		echo "</tr>";
    }					
	
} else {
    echo "0 results";
}
?> 
 </tbody>
</table>
<?php $mysqli->close();
?> 
