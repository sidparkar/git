<?php
session_start();

$user_id=$_SESSION["uid"];
include_once("config.php");

$sql="SELECT * from user WHERE user_id=".$_SESSION["uid"];
$res=$mysqli->query($sql);
$row=$res->fetch_assoc();

if(isset($_POST["submitform"]))
	{
		$product_name=$_POST["product_name"];
		
		$description=$_POST["description"];
		
		if(isset($_FILES['image'])){
			$errors="";
			$file_name=$_FILES['image']['name'];
			$file_size=$_FILES['image']['size'];
			$file_tmp=$_FILES['image']['tmp_name'];
			$file_type=$_FILES['image']['type'];
			//$file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
			//$extensions="jpg,jpeg,png,gif,tif";
			
			if($file_size > 5097152){
			 $errors='File size must be exactly 5 MB';
			}
			 move_uploaded_file($file_tmp,"images/".time().$file_name);
		}
		$image=time().$file_name;
		
		
		
			$sql="INSERT INTO product(product_name,description,image,user_id) values('$product_name','$description','$image','$user_id')";
			$res=$mysqli->query($sql);
			echo "<script>alert('Product Added...!');
	
			window.location.href='services.php';
			</script>";
		
		
	}

?>

<html>
<head><title>Service Form</title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
</head>
<body>
 <?php include_once("header.php");?>
<div class="container-fluid">
 <div class="row-fluid">
  <?php include_once("aside.php");?>
   <div class="span9" id="content">  
  <div class="block">
                              <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Add Services</div>
                            </div>
							 <div class="block-content collapse in">
							    <div class="span12">
									<!-- BEGIN FORM-->
									<form action="#" method="POST" enctype="multipart/form-data"  class="form-horizontal">
									<fieldset>
									<div class="alert alert-error hide">
								<button class="close" data-dismiss="alert"></button>
								You have some form errors. Please check below.
							</div>
							<div class="alert alert-success hide">
								<button class="close" data-dismiss="alert"></button>
								Your form validation is successful!
							</div>
							<div class="control-group">
  								<label class="control-label">Service Name<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" name="product_name" data-required="1" class="span6 m-wrap"/>
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Service Description <span class="required">*</span></label>
  								<div class="controls">
  									
									<textarea name="description" class="span6 m-wrap"> </textarea> 
  								</div>
  							</div>
							
							<div class="control-group">
  								<label class="control-label">Image<span class="required">*</span></label>
  								<div class="controls">
  									<input type="file" name="image" data-required="1" class="span6 m-wrap"/>
  								</div>
  							</div>
							<div class="form-actions">
  								<button type="submit" name="submitform" class="btn btn-primary">Save</button>
								
  							</div>
</fieldset>
</form>
</div>
</div>
</div>
</div>
</div>
            <footer>
                <p>&copy; Vincent Gabriel 2018</p>
            </footer>
</div>

 
</body>
</html>