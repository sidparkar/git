<?php include_once("config.php"); 

$sql="SELECT `uid`, `cname`, `agency`, `email_id`, `contact_no`, `date` FROM `client_info`";
	$res =$mysqli->query($sql); 
	if(!$res)
	{
		echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
	}


?>
<!DOCTYPE html>
<html>
    
    <head>
        <title>Tables</title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <link href="assets/DT_bootstrap.css" rel="stylesheet" media="screen">
        <!--[if lte IE 8]><script language="javascript" type="text/javascript" src="vendors/flot/excanvas.min.js"></script><![endif]-->
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    
    <body>
        <?php include_once("header.php"); ?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php include_once("aside.php"); ?>
                <!--/span-->
                <div class="span9" id="content">

                    

                   

                     

                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Bootstrap dataTables with Toolbar</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                   <div class="table-toolbar">
                                      <div class="btn-group">
                                         <a href="#"><button class="btn btn-success">Add New <i class="icon-plus icon-white"></i></button></a>
                                      </div>
                                      <div class="btn-group pull-right">
                                         <button data-toggle="dropdown" class="btn dropdown-toggle">Tools <span class="caret"></span></button>
                                         <ul class="dropdown-menu">
                                            <li><a href="#">Print</a></li>
                                            <li><a href="#">Save as PDF</a></li>
                                            <li><a href="#">Export to Excel</a></li>
                                         </ul>
                                      </div>
                                   </div>
                                    
                                    <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example2">
                                        <thead>
                                            <tr>
                                                <th>Sr.no</th>
                                                <th>Kind Attention</th>
                                                <th>Agency Name</th>
                                                <th>Email ID</th>
                                                <th>Mobile</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?php	
	while ($row = $res->fetch_assoc()) { 
			
	//1 button will be come here for link to products page with uid by get/post methode;

?>
                                            <tr class="odd gradeX">
                                                <td><?php echo $row['uid']; ?></td>
                                                <td><?php echo $row['cname']; ?></td>
                                                <td><?php echo $row['agency']; ?></td>
                                                <td><?php echo $row['email_id']; ?></td>
                                                <td><?php echo $row['contact_no']; ?></td>
                                                <td>
													<a class="btn" href="list_est.php?uid=<?php echo $row['uid']; ?>"><i class="icon-eye-open" ></i> View Estimate</a>
													<a class="btn btn-primary" ><i class="icon-pencil icon-white"></i> Edit User</a>
													
											        
												</td>
                                               
                                            </tr>
											
											<?php
											}
											?>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
            <hr>
            <?php include_once("footer.php"); ?>
        </div>
        <!--/.fluid-container-->

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/datatables/js/jquery.dataTables.min.js"></script>


        <script src="assets/scripts.js"></script>
        <script src="assets/DT_bootstrap.js"></script>
        <script>
        $(function() {
            
        });
        </script>
    </body>

</html>