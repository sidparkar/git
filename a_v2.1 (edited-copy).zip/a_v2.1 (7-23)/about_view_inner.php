
<?php


if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
} 
$about_id = $_GET["id"];
$sql = "SELECT about_id, name, designation,image FROM about_us where about_id=".$about_id;
$result = $mysqli->query($sql);
?> 
<style>
.product-image
{
	max-width:200px;	
}
</style>
<table class="table table-bordered">
	<thead>
		<tr>
			<th>id</th>
			<th>Name</th>
			<th>Designation</th>
			<th>Image</th>
		</tr>
	</thead>
	 <tbody>

<?php
if ($result->num_rows > 0) {
    // output data of each row
	
    while($row = $result->fetch_assoc()) {
		echo "<tr>";
		echo "<td>".$row["about_id"]."</td>";
       echo "<td>".$row["name"]."</td>";
	   echo "<td>".$row["designation"]."</td>";
		echo "<td><img src=images/{$row['image']} alt='{$row['image']}' class='img img-responsive product-image'/> </td>"; 
		echo "</tr>";
    }				
	
	
} else {
    echo "0 results";
}
?> 
 </tbody>
</table>
<?php $mysqli->close();
?> 
