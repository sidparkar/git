<?php 
include_once("config.php");

session_start();
$product_id = $_GET["id"];

$sql ="DELETE FROM product WHERE product_id=".$product_id;
$res=$mysqli->query($sql);
if(!$res){
	echo "Error" .$mysqli->error;
}

header('location:services.php');

?>