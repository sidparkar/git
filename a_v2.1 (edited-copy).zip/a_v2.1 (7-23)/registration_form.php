<?php

include_once("config.php");


if(isset($_POST["submitform"]))
	{
		$name=$_POST["name"];
		$username=$_POST["username"];
		$password=md5($_POST["password"]);
		
		$phone=$_POST["phone"];
		$email=$_POST["email"];																										
		
		$city=$_POST["city"];
	
		$date=date("d/m/y");
		
		$sql_u = "SELECT * FROm user WHERE username='$username'";
		$res_u = mysqli_query($mysqli,$sql_u);
		
		if(mysqli_num_rows($res_u) > 0){
			
			echo "Username Already Exist..!";
		}else {
		
		
		
		
			$sql="INSERT INTO user(name,username,password,phone,email,city,date) values('$name','$username','$password','$phone','$email','$city','$date')";
			$res=$mysqli->query($sql);
			echo "<script>alert('Thanyou ".$name." for Registration..!');
			window.location.href='login.php';
			</script>";
		}
		
		
	}

?>

<html>
<head><title>Regitration Form</title>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style> 
body{
	margin: 0 auto;
 background-image: url('./images/bg-2.jpeg');
 background-repeat: no-repeat;
 background-size: 100% 720px;
}
 
.container{
 width: 700px;
 height: 450px;
 text-align: center;
 margin: 0 auto;
 background-color: rgba(44, 62, 80,0.7);
 margin-top: 60px;
}
 
.container img{
 width: 150px;
 height: 150px;
 margin-top: -60px;
}
 
input[type="text"],input[type="password"]{
 margin-top: 30px;
 height: 45px;
 width: 300px;
 font-size: 18px;
 margin-bottom: 20px;
 background-color: #fff;
 padding-left: 40px;
}
 
.btn-login{
 padding: 15px 25px;
 border: none;
 background-color: #4788c7;
 color: #fff;
  border-radius: 22px;
}
.form_input {
    padding: 0px 14px;
}
h1
{
	 text-align: center;
    color: #fff;
    font-family: cursive;
}
.form_input::before{
 content: "\f007";
 font-family: "FontAwesome";
 padding-left: 07px;
 padding-top: 35px;
 position: absolute;
 font-size: 25px;
 color: #2980b9; 
}
.form_input:nth-child(2)::before{
 content: "\f070";
}
.form_input:nth-child(3)::before{
 content: "\f023";
}
.form_input:nth-child(4)::before{
 content: "\f0e0";
}
.form_input:nth-child(5)::before{
 content: "\f095";
}
.form_input:nth-child(6)::before{
 content: "\f0f7";
}
</style>
</head>
<body>

<h1>Registration Form </h1>
<div class="container">
<div class="row">
 <img src="images/person-female.png"/>
<form action="" method="POST">

<div class="col-md-6 form_input"><input type="text" name="name" placeholder="Enter Your Name"><br></div>
<div class="col-md-6 form_input"><input type="text" name="username" placeholder="Username"><br></div>
<div class="col-md-6 form_input"><input type="password" name="password" placeholder="Password"><br></div>
<div class="col-md-6 form_input"><input type="text" name="email" placeholder="enter your Email"><br></div>
<div class="col-md-6 form_input"><input type="text" name="phone" placeholder="enter your Phone"><br></div>
<div class="col-md-6 form_input"><input type="text" name="city" placeholder="enter your City"><br></div>

<button type="submit" name="submitform" class="btn-login">Submit Form </button>

</form>
</div>
</div>
</body>
</html>