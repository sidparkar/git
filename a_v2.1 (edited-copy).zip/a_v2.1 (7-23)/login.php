<?php
session_start();

if(isset($_SESSION["uid"]))
{
	header("location:index.php");
}
include_once("config.php");

		$errstatus=0;
		$errmsg="";
		if(isset($_POST["submitform"]))
		{
			$username=$_POST["username"];
			$password=md5($_POST["password"]);
			
			if($password=="")
			{
				$errstatus=1;
				$errmsg="Please enter password <br>";
			} 
			
			if($username=="")
			{
				$errstatus=1;
				$errmsg="Please enter Username <br>";
			}
			
			
			if($errstatus!=1)
			{
				$sql="SELECT  * FROM  user WHERE username='$username' AND password='$password'";
				$res =$mysqli->query($sql);
				
				if(!$res)
				{
					echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
					die();
				}
					
					
					
					/*-------------- Fetching row if that user exist--------------------*/
					if($res->num_rows==1)
					{
					    /*--------------set a session-----------*/
						$row= $res->fetch_assoc();
						
						$_SESSION["uid"]=$row["user_id"];
						/*--------------Redirected-----------*/
						header("location:index.php");
						
					}
					else
					{
						echo "wrong username or password";
					}
			}
		}
		
?>
<html>
<tiile>Login</title>
<head> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style> 
body{
	margin: 0 auto;
 background-image: url('./images/c-1.jpg');
 background-repeat: no-repeat;
 background-size: 100% 720px;
}
.container{
 width: 500px;
 height: 300px;
 text-align: center;
 margin: 0 auto;
 background-color: rgba(44, 62, 80,0.7);
 margin-top: 60px;
}
h1
{
	 text-align: center;
    color: #fff;
    font-family: cursive;
}
.btn-login{
 padding: 8px 35px;
 border: none;
 background-color: #4788c7;
 color: #fff;
     border-radius: 22px;
}
.form_input {
    padding: 0px 14px;
}
input[type="text"],input[type="password"]{
 margin-top: 20px;
 height: 45px;
 width: 300px;
 font-size: 18px;
 margin-bottom: 20px;
 background-color: #fff;
 padding-left: 40px;
}

.form_input::before{
 content: "\f007";
 font-family: "FontAwesome";
 padding-left: 07px;
 padding-top: 26px;
 position: absolute;
 font-size: 25px;
 color: #2980b9; 
}
.form_input:nth-child(2)::before{
 content: "\f023";
}
</style>
  </head>
	<body>
	<div class="container">
	<div class="row">
		<h1>Login</h1>
		<?php
			if($errstatus==1)
			echo $errmsg;
		?>
		<form action="" method="post">
			<div class="col-md-12 form_input"><input type="text" name="username" placeholder="Enter Username"></div>
			 <div class="col-md-12 form_input"><input type="password" name="password" placeholder="Password"> </div>
			<button type="submit" name="submitform" value="Login" class="btn-login">Login</button>
		
		</form>
		</div>
		</div>
	</body>
</html>