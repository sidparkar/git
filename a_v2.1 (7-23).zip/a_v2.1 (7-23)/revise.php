<?php include_once("config.php"); 
    $estid = $_GET["estid"]; 
$sql="SELECT `pid`, `est_id`, `uid`, `title`, `director`, `duration`, `format`, `edit`, `dubs`, `scope_of_work`, `cost_include`, `cost_exclude`, `note`, `price` FROM `product_info` WHERE est_id = '".$estid."'";
		$res =$mysqli->query($sql); 
		if(!$res)
		{
			echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
		}
?>
<!DOCTYPE html>
<html>
    
    <head>
        <title>Tables</title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <link href="assets/DT_bootstrap.css" rel="stylesheet" media="screen">
        <!--[if lte IE 8]><script language="javascript" type="text/javascript" src="vendors/flot/excanvas.min.js"></script><![endif]-->
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    
    <body>
        <?php include_once("header.php"); ?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php include_once("aside.php"); ?>
                <!--/span-->
                <div class="span9" id="content">

                    

                   <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left"><?php echo $estid; ?></div>
                            </div>
							<?php
								while ($row = $res->fetch_assoc()) { 
							?>
							<div class="navbar navbar-inner block-header">
                                <div class="muted pull-left"><?php echo $row['title']; ?></div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
								<table class="tables">
								<tr><td>Title </td><td><i class="icon-arrow-right"></i> <?php echo $row['title']; ?></td></tr>
								<tr><td>Director </td><td><i class="icon-arrow-right"></i> <?php echo $row['director']; ?></td></tr>
								<tr><td>Duration </td><td><i class="icon-arrow-right"></i> <?php echo $row['duration']; ?></td></tr>
								<tr><td>Format </td><td><i class="icon-arrow-right"></i> <?php echo $row['format']; ?></td></tr>
								<tr><td>Edit </td><td><i class="icon-arrow-right"></i> <?php echo $row['edit']; ?></td></tr>
								<tr><td>Dubs </td><td><i class="icon-arrow-right"></i> <?php echo $row['dubs']; ?></td></tr>
								<tr><td>Scope of work </td><td><i class="icon-arrow-right"></i> <?php echo $row['scope_of_work']; ?></td></tr>
								<tr><td>Cost Include </td><td><i class="icon-arrow-right"></i> <?php echo $row['cost_exclude']; ?></td></tr>
								<tr><td>Cost Exclude  </td><td><i class="icon-arrow-right"></i><?php echo $row['cost_include']; ?></td></tr>
								<tr><td>Note </td><td><i class="icon-arrow-right"></i> <?php echo $row['note']; ?></td></tr>
								<tr><td>Price </td><td><i class="icon-arrow-right"></i> <?php echo $row['price']?></td></tr>
								</table>
                                </div>
                            </div>
							<?php }	?>
                        </div>
                        <!-- /block -->
                    </div>

                    
                </div>
            </div>
            <hr>
            <?php include_once("footer.php"); ?>
        </div>
        <!--/.fluid-container-->

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/datatables/js/jquery.dataTables.min.js"></script>


        <script src="assets/scripts.js"></script>
        <script src="assets/DT_bootstrap.js"></script>
        <script>
        $(function() {
            
        });
        </script>
    </body>

</html>