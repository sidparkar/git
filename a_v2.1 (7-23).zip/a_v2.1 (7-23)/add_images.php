
<?php
session_start();

include_once("config.php");


$sql="SELECT * from user WHERE user_id=".$_SESSION["uid"];
$res=$mysqli->query($sql);
$row=$res->fetch_assoc();
$sql_p="SELECT * FROM product WHERE user_id=".$_SESSION["uid"];
$res_p=$mysqli->query($sql_p);
?>

<!DOCTYPE html>
<html>
    
    <head>
        <title>Services</title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    
    <body>
       
       
                <!--/span-->
				  <?php include_once("header.php");?>
        <div class="container-fluid">
            <div class="row-fluid">
               
                    <?php include_once("aside.php");?>
                <div class="span9" id="content">             
                    <div class="row-fluid">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">Add Services</div>
                                </div>
                                <div class="block-content collapse in">
                                    <div class="span12">
									
								                    <?php include_once("home.php");?>
                                    </div>
                                </div>
                            </div>
                            <!-- /block -->
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <p>&copy; Vincent Gabriel 2013</p>
            </footer>
        </div>
        <!--/.fluid-container-->
        <script src="vendors/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/scripts.js"></script>
        <script>
        $(function() {
            
        });
        </script>
    </body>

</html>