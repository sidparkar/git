<?php


if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
} 
$product_id = $_GET["id"];
$sql = "SELECT product_id, product_name,image,description FROM product where product_id=".$product_id;
$result = $mysqli->query($sql);
 ?>
 
<style type="text/css">
	.product-image {
		max-width:200px;
	}
</style>

<table class="table table-bordered ">
	<thead>
		<tr>
			<th>id</th>
			<th>name</th>
			<th>image</th>
			<th>description</th>
		</tr>
	 </thead>
	 <tbody>
	 <?php
		if ($result->num_rows > 0) {
    // output data of each row
			while($row = $result->fetch_assoc()) {
				echo "<tr>";
				echo "<td>".$row["product_id"]."</td>";
				echo "<td>".$row["product_name"]."</td>";
				echo "<td><img src=images/{$row['image']} alt='{$row['image']}' class='img img-responsive product-image'/> </td>"; 
				echo "<td>".$row["description"]."</td>" ;
				echo "</tr>";
			}
		} else {
			echo "0 results";
		}
		?>
	 </tbody>
</table>
<?php $mysqli->close(); ?> 
