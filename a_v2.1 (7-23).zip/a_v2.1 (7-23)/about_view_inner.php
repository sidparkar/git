<!DOCTYPE html>
<html>
<body>
<?php


if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
} 
$about_id = $_GET["id"];
$sql = "SELECT about_id, name, designation FROM about_us where about_id=".$about_id;
$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	
    while($row = $result->fetch_assoc()) {
        echo "<br> id: ". $row["about_id"]. " - Name: ". $row["name"]. " - Designation:" . $row["designation"] .  "<br>";
    }				
	
	
} else {
    echo "0 results";
}

$mysqli->close();
?> 

</body>
</html>