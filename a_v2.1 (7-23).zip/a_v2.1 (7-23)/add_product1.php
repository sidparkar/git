<?php
session_start();

if(!isset($_SESSION["uid"]))
{
	header("location:login.php");
}

$user_id=$_SESSION["uid"];
include_once("config.php");


if(isset($_POST["submitform"]))
	{
		$product_name=$_POST["product_name"];
		
		$description=$_POST["description"];
		
		if(isset($_FILES['image'])){
			$errors="";
			$file_name=$_FILES['image']['name'];
			$file_size=$_FILES['image']['size'];
			$file_tmp=$_FILES['image']['tmp_name'];
			$file_type=$_FILES['image']['type'];
			//$file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
			//$extensions="jpg,jpeg,png,gif,tif";
			
			if($file_size > 5097152){
			 $errors='File size must be exactly 5 MB';
			}
			 move_uploaded_file($file_tmp,"images/".time().$file_name);
		}
		$image=time().$file_name;
		
		
		
		
		
		
			$sql="INSERT INTO product(product_name,description,image,user_id) values('$product_name','$description','$image','$user_id')";
			$res=$mysqli->query($sql);
			echo "<script>alert('Product Added...!');
			window.location.href='home.php';
			</script>";
		
	}

?>

<html>
<head><title>Regitration Form</title></head>
<body>

<h3>Registration Form </h3>

<form action="" method="POST" enctype="multipart/form-data">

Product name  <input type="text" name="product_name"><br><br>
Description  <textarea name="description"> </textarea> <br><br>
<br>

Image <input type="file" name="image"><br> <br>

<button type="submit" name="submitform">Submit Form </button>

</form>

</body>
</html>