
                <div class="span3" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse" style="display:inherit;">
                        <li class="active">
                            <a href="index.php"><i class="icon-chevron-right"></i> Dashboard</a>
                        </li>                   
						<li>
                            <a href="about.php"><i class="icon-chevron-right"></i>About Us</a>
                        </li>
						<li>
                            <a href="services.php"><i class="icon-chevron-right"></i> Add Services</a>
                        </li>
						<li>
                            <a href="gallery.php"><i class="icon-chevron-right"></i>Gallery</a>
                        </li>
                       
                    </ul>
                </div>