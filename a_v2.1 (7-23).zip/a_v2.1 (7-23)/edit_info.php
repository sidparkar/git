<?php

session_start();

if(!isset($_SESSION["uid"]))
{
	header("location:login.php");
}

include_once("config.php");

$sql="SELECT * from user WHERE user_id=".$_SESSION["uid"];
$res=$mysqli->query($sql);
$row=$res->fetch_assoc();

$sql_u="SELECT * FROM user WHERE user_id=".$_SESSION["uid"];
$res_u=$mysqli->query($sql_u);
$row_u=$res_u->fetch_assoc();


if(isset($_POST["submitform"]))
	{
		$name=$_POST["name"];
		$username=$_POST["username"];
		//$password=md5($_POST["password"]);
		
		$phone=$_POST["phone"];
		$email=$_POST["email"];																										
		
		$city=$_POST["city"];
	
		//$date=date("d/m/y");
		
		$sql="UPDATE user SET name='$name', username='$username', phone='$phone',email='$email',city='$city' WHERE user_id=".$_SESSION["uid"];
			$res=$mysqli->query($sql);
			echo "<script>alert('Updated Successfully ..!');
			window.location.href='services.php';
			</script>";
		
		
		
	}

?>

<html>
<head><title>Edit Form</title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
</head>
<body>
 <?php include_once("header.php");?>
<div class="container-fluid">
 <div class="row-fluid">
  <?php include_once("aside.php");?>
   <div class="span9" id="content">  
  <div class="block">
                              <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Edit Information</div>
                            </div>
							 <div class="block-content collapse in">
							    <div class="span12">
									<!-- BEGIN FORM-->
<form action="" method="POST" enctype="multipart/form-data"  class="form-horizontal">
<fieldset>
									<div class="alert alert-error hide">
								<button class="close" data-dismiss="alert"></button>
								You have some form errors. Please check below.
							</div>
							<div class="alert alert-success hide">
								<button class="close" data-dismiss="alert"></button>
								Your form validation is successful!
							</div>
							<div class="control-group">
  								<label class="control-label">Name<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" name="name" value="<?php echo $row_u["name"]; ?>" data-required="1" class="span6 m-wrap"/>
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Username <span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" name="username" value="<?php echo $row_u["username"]; ?>" data-required="1" class="span6 m-wrap"/>
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Email<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" name="email" value="<?php echo $row_u["email"]; ?>" data-required="1" class="span6 m-wrap"/>
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">Phone<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" name="phone" value="<?php echo $row_u["phone"]; ?>" data-required="1" class="span6 m-wrap"/>
  								</div>
  							</div>
							<div class="control-group">
  								<label class="control-label">City<span class="required">*</span></label>
  								<div class="controls">
  									<input type="text" name="city" value="<?php echo $row_u["city"]; ?>" data-required="1" class="span6 m-wrap"/>
  								</div>
  							</div>
<div class="form-actions">
  								<button type="submit" name="submitform" class="btn btn-primary">Save</button>
								
  							</div>
</fieldset>
</form>
</div>
</div>
</div>
</div>
</div>
            <footer>
                <p>&copy; Vincent Gabriel 2018</p>
            </footer>
</div>

</body>
</html>