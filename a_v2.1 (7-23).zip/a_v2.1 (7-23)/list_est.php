<?php
include_once("config.php"); 
$uid=$_GET["uid"];

$sql="SELECT `est_id`, `uid`, `invoice`, `invoice_id`, `date` FROM `est_info` WHERE uid=".$uid;
	$res =$mysqli->query($sql); 
	if(!$res)
	{
		echo "Error: (" . $mysqli->errno . ") " . $mysqli->error;
	}
?>
<!DOCTYPE html>
<html>
    
    <head>
        <title>Estimate list</title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <link href="assets/DT_bootstrap.css" rel="stylesheet" media="screen">
        <!--[if lte IE 8]><script language="javascript" type="text/javascript" src="vendors/flot/excanvas.min.js"></script><![endif]-->
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    
    <body>
        <?php include_once("header.php"); ?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php include_once("aside.php"); ?>
                <!--/span-->
                <div class="span9" id="content">

                    

                   

                     

                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Bootstrap dataTables with Toolbar</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                   <div class="table-toolbar">
                                      <div class="btn-group">
                                         <a href="#"><button class="btn btn-success">Add New <i class="icon-plus icon-white"></i></button></a>
                                      </div>
                                      <div class="btn-group pull-right">
                                         <button data-toggle="dropdown" class="btn dropdown-toggle">Tools <span class="caret"></span></button>
                                         <ul class="dropdown-menu">
                                            <li><a href="#">Print</a></li>
                                            <li><a href="#">Save as PDF</a></li>
                                            <li><a href="#">Export to Excel</a></li>
                                         </ul>
                                      </div>
                                   </div>
                                    
                                    <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example2">
                                        <thead>
                                            <tr>
                                                <th>Estimate ID</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?php	
	while ($row = $res->fetch_assoc()) { 
			
	//1 button will be come here for link to products page with uid by get/post methode;

?>
                                            <tr class="odd gradeX">
                                                <td><?php echo $row['est_id']; ?></td>
                                                <td>
												<div class="btn-group">
													<a class="btn btn-primary btn-mini" ><i class="icon-pencil icon-white"></i> Edit</a>
													<a class="btn btn-success btn-mini" href="revise.php?estid=<?php echo $row['est_id']; ?>"><i class="icon-plus-sign icon-white"></i> Update</a>
													<a class="btn btn-success btn-mini" ><i class="icon-ok icon-white"></i> Invoice</a>
												</div>
												</td>
                                               
                                            </tr>
											
											<?php
											}
											?>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
            <hr>
            <?php include_once("footer.php"); ?>
        </div>
        <!--/.fluid-container-->

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/datatables/js/jquery.dataTables.min.js"></script>


        <script src="assets/scripts.js"></script>
        
        <script>
        $(function() {
            
        });
        </script>
    </body>

</html>