<?php 
include_once("config.php");

session_start();
$img_id = $_GET["id"];

$sql ="DELETE FROM gallery WHERE img_id=".$img_id;
$res=$mysqli->query($sql);
if(!$res){
	echo "Error" .$mysqli->error;
}

header('location:gallery.php');

?>