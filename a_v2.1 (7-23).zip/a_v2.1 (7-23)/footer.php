<footer>
                <p>&copy; abc</p>
            </footer>