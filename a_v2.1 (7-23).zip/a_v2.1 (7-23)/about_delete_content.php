<?php 
include_once("config.php");

session_start();
$about_id = $_GET["id"];

$sql ="DELETE FROM about_us WHERE about_id=".$about_id;
$res=$mysqli->query($sql);
if(!$res){
	echo "Error" .$mysqli->error;
}

header('location:about.php');

?>