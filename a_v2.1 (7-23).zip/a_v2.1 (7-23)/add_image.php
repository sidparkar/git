
<style> </style>
	

<div class="" style="margin-bottom:10px;"><button class="btn btn-success"><a href="add_picture.php"><span class="" style= "color:white;">Add Image </span><i class="icon-plus icon-white"></i></a></button></div>
<div><table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
<thead><tr><th>Sr.no</th><th>Image</th> <th>Action</th></tr></thead>
<?php $i=1;
while($row_p=$res_p->fetch_assoc()){
?>
<tbody>
<tr>
<td><?php echo $i;?></td>

<td><img src="images/<?php echo $row_p["image"];?>" width="100px"></td>
<td><a href="delete_image.php?id=<?php echo $row_p["img_id"];?>"><i class="icon-trash"></i></a>
<span class="edit-space" style="padding-left:10px;"><a href="edit-image.php?id=<?php echo $row_p["img_id"];?>"><i class="icon-edit"></i></a></span>
<span class="edit-space" style="padding-left:10px;"><a href="view-image.php?id=<?php echo $row_p["img_id"];?>"><i class="icon-eye-open"></i></a></span>
</td>
</tr>
<?php $i++; } ?>
</tbody>
</table>
</div>