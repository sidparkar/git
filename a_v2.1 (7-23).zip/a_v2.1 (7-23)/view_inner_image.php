<!DOCTYPE html>
<html>
<body>
<?php


if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
} 
$img_id = $_GET["id"];
$sql = "SELECT img_id, image FROM gallery where img_id=".$img_id;
$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	
    while($row = $result->fetch_assoc()) {
        echo "<br> id: ". $row["img_id"]. " - image: ". $row["image"].   "<br>";
    }				
	
	
} else {
    echo "0 results";
}

$mysqli->close();
?> 

</body>
</html>