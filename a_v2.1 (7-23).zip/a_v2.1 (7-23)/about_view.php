<?php
session_start();

$user_id=$_SESSION["uid"];
include_once("config.php");

$sql="SELECT * from user WHERE user_id=".$_SESSION["uid"];
$res=$mysqli->query($sql);
$row=$res->fetch_assoc();



?>

<html>
<head><title>About Content Form</title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
</head>
<body>
 <?php include_once("header.php");?>
<div class="container-fluid">
 <div class="row-fluid">
  <?php include_once("aside.php");?>
   <div class="span9" id="content">  
  <div class="block">
                              <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">View Service</div>
                            </div>
							 <div class="block-content collapse in">
							    <div class="span12">
									<!-- BEGIN FORM-->
									<?php include_once("about_view_inner.php");?>
</div>
</div>
</div>
</div>
</div>
<hr>
            <footer>
                <p>&copy; Vincent Gabriel 2018</p>
            </footer>
</div>

 
</body>
</html>